$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("login.feature");
formatter.feature({
  "line": 1,
  "name": "Free CRM Login Feature",
  "description": "",
  "id": "free-crm-login-feature",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Free CRM Login Test Scenario",
  "description": "",
  "id": "free-crm-login-feature;free-crm-login-test-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Title of Login Page is Free CRM",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User  enters \"naveenk\" and \"test@123\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "user clicks on Login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "it navigates to Home Page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginStepDefinition.user_is_on_Login_Page()"
});
formatter.result({
  "duration": 9263776462,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.title_of_Login_Page_is_Free_CRM()"
});
formatter.result({
  "duration": 19210376,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "naveenk",
      "offset": 14
    },
    {
      "val": "test@123",
      "offset": 28
    }
  ],
  "location": "LoginStepDefinition.user_enters_username_and_password(String,String)"
});
formatter.result({
  "duration": 229170524,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.user_clicks_on_Login_button()"
});
formatter.result({
  "duration": 4325972887,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefinition.it_navigates_to_Home_Page()"
});
formatter.result({
  "duration": 2841664248,
  "status": "passed"
});
});